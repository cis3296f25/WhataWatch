<h2 id="extract_user_films">extract_user_films(user: letterboxdpy.user.User, url: str = None) -> dict</h2>

**Documentation:**

Extracts user films and their details from the given URL or returns all watched films.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+extract_user_films)
