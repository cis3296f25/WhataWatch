<h2 id="print_movies">print_movies(movies, title=None, max_count=None)</h2>

**Documentation:**

Print movies in a formatted list.

[To be documented.](https://github.com/search?q=repo:nmcassa/letterboxdpy+print_movies)
